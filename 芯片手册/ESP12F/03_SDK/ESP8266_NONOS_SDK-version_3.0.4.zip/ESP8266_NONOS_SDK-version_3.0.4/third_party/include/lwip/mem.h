/*
 * Copyright (c) 2001-2004 Swedish Institute of Computer Science.
 * All rights reserved. 
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 */
#ifndef __LWIP_MEM_H__
#define __LWIP_MEM_H__

#include "lwip/opt.h"
//#include "mem_manager.h"

#ifdef __cplusplus
extern "C" {
#endif

#if MEM_LIBC_MALLOC

#include <stddef.h> /* for size_t */

typedef size_t mem_size_t;

void *pvPortMalloc (size_t sz, const char *, unsigned, bool);
void vPortFree (void *p, const char *, unsigned);
void *pvPortZalloc (size_t sz, const char *, unsigned);
void *pvPortRealloc (void *p, size_t n, const char *, unsigned);
void* pvPortCalloc(size_t count,size_t size,const char *,unsigned);
void* pvPortCallocIram(size_t count,size_t size,const char *,unsigned);
void *pvPortZallocIram (size_t sz, const char *, unsigned);

/* aliases for C library malloc() */
#define mem_init()
/* in case C library malloc() needs extra protection,
 * allow these defines to be overridden.
 */
#ifndef MEMLEAK_DEBUG
#ifndef mem_free
#define mem_free(s)        vPortFree(s, "", __LINE__)
#endif
#ifndef mem_malloc
#define mem_malloc(s)      pvPortMalloc(s, "", __LINE__,false)
#endif
#ifndef mem_calloc
#define mem_calloc(l, s)   pvPortCalloc(l, s, "", __LINE__)
#endif
#ifndef mem_realloc
#define mem_realloc(p, s)  pvPortRealloc(p, s, "", __LINE__)
#endif
#ifndef mem_zalloc
#define mem_zalloc(s)     pvPortZalloc(s, "", __LINE__)
#endif
#else
#ifndef mem_free
#define mem_free(s)      vPortFree(s, mem_debug_file, __LINE__)
#endif

#ifndef mem_malloc
#define mem_malloc(s)   pvPortMalloc(s, mem_debug_file, __LINE__,false)
#endif
#ifndef mem_calloc
#define mem_calloc(l, s)  pvPortCalloc(l, s, mem_debug_file, __LINE__)
#endif
#ifndef mem_realloc
#define mem_realloc(p, s) pvPortRealloc(p, s, mem_debug_file, __LINE__)
#endif
#ifndef mem_zalloc
#define mem_zalloc(s)   pvPortZalloc(s, mem_debug_file, __LINE__)
#endif

#endif

#ifndef os_malloc
#ifndef MEMLEAK_DEBUG
#define os_malloc(s) pvPortMalloc(s, "", __LINE__,true)
#else
#define os_malloc(s) pvPortMalloc(s, mem_debug_file, __LINE__,true)
#endif
#endif
#ifndef os_realloc
#define os_realloc(p, s) mem_realloc((p), (s))
#endif
#ifndef os_zalloc
#define os_zalloc(s) mem_zalloc((s))
#endif
#ifndef os_free
#define os_free(p) mem_free((p))
#endif

/* Since there is no C library allocation function to shrink memory without
   moving it, define this to nothing. */
#ifndef mem_trim
#define mem_trim(mem, size) (mem)
#endif
#else /* MEM_LIBC_MALLOC */

/* MEM_SIZE would have to be aligned, but using 64000 here instead of
 * 65535 leaves some room for alignment...
 */
#if MEM_SIZE > 64000l
typedef u32_t mem_size_t;
#define MEM_SIZE_F U32_F
#else
typedef u16_t mem_size_t;
#define MEM_SIZE_F U16_F
#endif /* MEM_SIZE > 64000 */

#if MEM_USE_POOLS
/** mem_init is not used when using pools instead of a heap */
#define mem_init()
/** mem_trim is not used when using pools instead of a heap:
    we can't free part of a pool element and don't want to copy the rest */
#define mem_trim(mem, size) (mem)
#else /* MEM_USE_POOLS */
/* lwIP alternative malloc */
void  mem_init(void)ICACHE_FLASH_ATTR;
void *mem_trim(void *mem, mem_size_t size)ICACHE_FLASH_ATTR;
#endif /* MEM_USE_POOLS */
void *mem_malloc(mem_size_t size)ICACHE_FLASH_ATTR;
void *mem_calloc(mem_size_t count, mem_size_t size)ICACHE_FLASH_ATTR;
void  mem_free(void *mem)ICACHE_FLASH_ATTR;
#endif /* MEM_LIBC_MALLOC */

/** Calculate memory size for an aligned buffer - returns the next highest
 * multiple of MEM_ALIGNMENT (e.g. LWIP_MEM_ALIGN_SIZE(3) and
 * LWIP_MEM_ALIGN_SIZE(4) will both yield 4 for MEM_ALIGNMENT == 4).
 */
#ifndef LWIP_MEM_ALIGN_SIZE
#define LWIP_MEM_ALIGN_SIZE(size) (((size) + MEM_ALIGNMENT - 1) & ~(MEM_ALIGNMENT-1))
#endif

/** Calculate safe memory size for an aligned buffer when using an unaligned
 * type as storage. This includes a safety-margin on (MEM_ALIGNMENT - 1) at the
 * start (e.g. if buffer is u8_t[] and actual data will be u32_t*)
 */
#ifndef LWIP_MEM_ALIGN_BUFFER
#define LWIP_MEM_ALIGN_BUFFER(size) (((size) + MEM_ALIGNMENT - 1))
#endif

/** Align a memory pointer to the alignment defined by MEM_ALIGNMENT
 * so that ADDR % MEM_ALIGNMENT == 0
 */
#ifndef LWIP_MEM_ALIGN
#define LWIP_MEM_ALIGN(addr) ((void *)(((mem_ptr_t)(addr) + MEM_ALIGNMENT - 1) & ~(mem_ptr_t)(MEM_ALIGNMENT-1)))
#endif

#ifdef __cplusplus
}
#endif

#endif /* __LWIP_MEM_H__ */
